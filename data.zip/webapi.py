from flask import Flask, flash, redirect, render_template, request, session, abort
from rasa_nlu.model import Metadata, Interpreter 
from flask import jsonify
app = Flask(__name__)
from weather import Weather, Unit
weather = Weather(unit=Unit.CELSIUS)
from flask_cors import CORS
CORS(app)
@app.route("/")
def index():
    return "Flask App!"
 
@app.route("/api/<string:query>/")
def hello(query):
    interpreter = Interpreter.load("C:/Users/avsim/Desktop/Rasa-CustomBot/models/nlu/default/current")
    return jsonify(interpreter.parse(query))
 
@app.route("/w")
def w():
    location = weather.lookup_by_location('gurgaon')
    condition = location.condition
    return jsonify(condition.text)
 
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=80)